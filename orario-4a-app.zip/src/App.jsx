import React, { useMemo, useState } from "react"

const DAYS = ["Lunedì","Martedì","Mercoledì","Giovedì","Venerdì"]
const SLOTS = ["08:15–09:15","09:15–10:15","10:15–11:15","11:15–12:15","12:15–13:15","13:15–14:15"]

const RAW = {
  "08:15–09:15": {
    "Lunedì": { subject: "Italiano", teacher: "Longo" },
    "Martedì": { subject: "Matematica", teacher: "Sperti" },
    "Mercoledì": { subject: "Tecn./Musica", teacher: "Mita" },
    "Giovedì": { subject: "Scienze", teacher: "Sperti" },
    "Venerdì": { subject: "Italiano", teacher: "Longo" },
  },
  "09:15–10:15": {
    "Lunedì": { subject: "Italiano", teacher: "Longo" },
    "Martedì": { subject: "Matematica", teacher: "Sperti" },
    "Mercoledì": { subject: "Italiano", teacher: "Longo" },
    "Giovedì": { subject: "Scienze", teacher: "Sperti" },
    "Venerdì": { subject: "Italiano", teacher: "Longo / Sperti" },
  },
  "10:15–11:15": {
    "Lunedì": { subject: "Inglese", teacher: "De Marco" },
    "Martedì": { subject: "Storia", teacher: "Longo" },
    "Mercoledì": { subject: "Italiano", teacher: "Longo" },
    "Giovedì": { subject: "Religione", teacher: "Bramato" },
    "Venerdì": { subject: "Matematica", teacher: "Sperti" },
  },
  "11:15–12:15": {
    "Lunedì": { subject: "Inglese", teacher: "De Marco" },
    "Martedì": { subject: "Tecn./Musica", teacher: "Mita" },
    "Mercoledì": { subject: "Matematica", teacher: "Sperti / Longo" },
    "Giovedì": { subject: "Storia", teacher: "Longo" },
    "Venerdì": { subject: "Matematica", teacher: "Sperti" },
  },
  "12:15–13:15": {
    "Lunedì": { subject: "Ed. Fisica", teacher: "Battipaglia" },
    "Martedì": { subject: "Inglese", teacher: "De Marco" },
    "Mercoledì": { subject: "Matematica", teacher: "Sperti" },
    "Giovedì": { subject: "Storia", teacher: "Longo" },
    "Venerdì": { subject: "Religione", teacher: "Bramato" },
  },
  "13:15–14:15": {
    "Lunedì": { subject: "Geografia", teacher: "Sperti / Longo" },
    "Martedì": { subject: "Ed. Fisica", teacher: "Battipaglia" },
    "Mercoledì": { subject: "Geografia", teacher: "Sperti" },
    "Giovedì": { subject: "—", teacher: "—" },
    "Venerdì": { subject: "Arte e Immag", teacher: "Longo" },
  },
}

const entries = Object.entries(RAW).flatMap(([slot, dayMap]) =>
  DAYS.map((d) => {
    const v = dayMap[d] || undefined
    return { day: d, slot, subject: v?.subject ?? "—", teacher: v?.teacher ?? "—" }
  })
)

const unique = (arr) => Array.from(new Set(arr)).filter(Boolean).sort((a,b)=>a.localeCompare(b,"it"))
const SUBJECTS = unique(entries.map(e => e.subject).filter(s => s !== "—"))
const TEACHERS = unique(entries.flatMap(e => e.teacher.split("/").map(t => t.trim())).filter(t => t !== "—"))

export default function App(){
  const [day, setDay] = useState("Tutti")
  const [slot, setSlot] = useState("Tutte")
  const [subject, setSubject] = useState("Tutte")
  const [teacher, setTeacher] = useState("Tutti")
  const [query, setQuery] = useState("")
  const [compact, setCompact] = useState(false)

  const filtered = useMemo(() => {
    return entries.filter(e => {
      if (day !== "Tutti" && e.day !== day) return false
      if (slot !== "Tutte" && e.slot !== slot) return false
      if (subject !== "Tutte" && e.subject !== subject) return false
      if (teacher !== "Tutti" && !e.teacher.toLowerCase().includes(teacher.toLowerCase())) return false
      if (query) {
        const q = query.toLowerCase()
        const hay = `${e.day} ${e.slot} ${e.subject} ${e.teacher}`.toLowerCase()
        if (!hay.includes(q)) return false
      }
      return true
    })
  }, [day, slot, subject, teacher, query])

  const isDefault = day === "Tutti" && slot === "Tutte" && subject === "Tutte" && teacher === "Tutti" && !query
  const visibleDays = (isDefault ? DAYS : unique(filtered.map(e=>e.day)))
  const visibleSlots = (isDefault ? SLOTS : unique(filtered.map(e=>e.slot)))

  const exportCSV = () => {
    const header = ["Giorno","Orario","Materia","Docente"]
    const rows = filtered.map(e => [e.day, e.slot, e.subject, e.teacher])
    const csv = [header, ...rows].map(r => r.map(c => `"${String(c).replaceAll('"','""')}"`).join(",")).join("\n")
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "orario-4A.csv"
    a.click()
    URL.revokeObjectURL(url)
  }

  const reset = () => {
    setDay("Tutti"); setSlot("Tutte"); setSubject("Tutte"); setTeacher("Tutti"); setQuery("")
  }

  return (
    <>
      <header>
        <div className="container controls">
          <div className="brand">
            <div className="badge">4A</div>
            <div>
              <h1 className="h1">Scuola Primaria “Roberto Caputo”</h1>
              <p className="h2">Orario Classe 4^A · A.S. 2025/2026</p>
            </div>
          </div>
          <div className="row">
            <label className="small">Vista compatta</label>
            <input type="checkbox" className="switch" checked={compact} onChange={e=>setCompact(e.target.checked)} />
            <button className="btn primary" onClick={exportCSV}>Scarica CSV</button>
          </div>
        </div>
      </header>

      <main className="container" style={{paddingBottom:24}}>
        <div className="card" style={{marginTop:16}}>
          <div className="body">
            <div className="grid filters">
              <div>
                <label>Giorno</label>
                <select value={day} onChange={e=>setDay(e.target.value)}>
                  <option value="Tutti">Tutti</option>
                  {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
                </select>
              </div>
              <div>
                <label>Fascia oraria</label>
                <select value={slot} onChange={e=>setSlot(e.target.value)}>
                  <option value="Tutte">Tutte</option>
                  {SLOTS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label>Materia</label>
                <select value={subject} onChange={e=>setSubject(e.target.value)}>
                  <option value="Tutte">Tutte</option>
                  {SUBJECTS.map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div>
                <label>Docente</label>
                <select value={teacher} onChange={e=>setTeacher(e.target.value)}>
                  <option value="Tutti">Tutti</option>
                  {TEACHERS.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div>
                <label>Ricerca libera</label>
                <input type="text" value={query} onChange={e=>setQuery(e.target.value)} placeholder="Es. Italiano, De Marco…" />
              </div>
            </div>

            <div className="row" style={{marginTop:10, justifyContent:'space-between'}}>
              <div className="small">Risultati: <strong>{filtered.length}</strong></div>
              <div className="row">
                <button className="btn" onClick={reset}>Reset</button>
              </div>
            </div>
          </div>
        </div>

        {!compact ? (
          <div className="table-wrap" style={{marginTop:16}}>
            <table>
              <thead>
                <tr>
                  <th>Orario</th>
                  {visibleDays.map(d => <th key={d}>{d}</th>)}
                </tr>
              </thead>
              <tbody>
                {visibleSlots.map(s => (
                  <tr key={s}>
                    <td><span className="subject">{s}</span></td>
                    {visibleDays.map(d => {
                      const e = filtered.find(x => x.day === d && x.slot === s)
                      if (!isDefault && !e) return <td key={d}></td>
                      const base = e || entries.find(x => x.day === d && x.slot === s)
                      return (
                        <td key={d}>
                          <div className="subject">{base?.subject ?? "—"}</div>
                          <div className="teacher">{base?.teacher ?? "—"}</div>
                        </td>
                      )
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="list" style={{marginTop:16}}>
            {filtered.map((e,i) => (
              <div className="list-card" key={`${e.day}-${e.slot}-${i}`}>
                <div className="row">
                  <div className="dot">{e.day.slice(0,2)}</div>
                  <div>
                    <div className="small">{e.day} · {e.slot}</div>
                    <div className="subject">{e.subject}</div>
                    <div className="teacher">{e.teacher}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <div className="footer">
        Tema scuola: blu istituzionale e giallo scuola. Dati da PDF. Se noti discrepanze, segnala l’ora e il giorno.
      </div>
    </>
  )
}
