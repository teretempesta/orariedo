# Orario Classe 4^A – App Interattiva (Vite + React)

## Avvio locale
```bash
npm install
npm run dev
```
Apri il link mostrato dal terminale.

## Build produzione
```bash
npm run build
npm run preview
```

## Deploy su Vercel
1. Carica questa cartella su un repository GitHub (o caricala su Vercel con "Import Project").
2. Vercel rileverà Vite. Build command: `npm run build`. Output: `dist`.
3. Pubblica. Otterrai un URL del tipo `https://orario-4a.vercel.app`.
